#! /usr/bin/env python
# -*- coding: utf-8 -*-

from main import main

main(revisions=["issue583-v1", "issue583-v2"])
